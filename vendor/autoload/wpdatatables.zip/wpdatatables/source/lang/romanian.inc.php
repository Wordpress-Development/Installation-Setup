{
    "sProcessing":   "Proceseaza...",
    "sLengthMenu":   "Afiseaza _MENU_ inregistrari pe pagina",
    "sZeroRecords":  "Nu am gasit nimic - ne pare rau",
    "sInfo":         "Afisate de la _START_ la _END_ din _TOTAL_ inregistrari",
    "sInfoEmpty":    "Afisate de la 0 la 0 din 0 inregistrari",
    "sInfoFiltered": "(filtrate dintr-un total de _MAX_ inregistrari)",
    "sInfoPostFix":  "",
    "sSearch":       "Cauta:",
    "sUrl":          "",
    "oPaginate": {
        "sFirst":    "Prima",
        "sPrevious": "Precedenta",
        "sNext":     "Urmatoarea",
        "sLast":     "Ultima"
    }
}
